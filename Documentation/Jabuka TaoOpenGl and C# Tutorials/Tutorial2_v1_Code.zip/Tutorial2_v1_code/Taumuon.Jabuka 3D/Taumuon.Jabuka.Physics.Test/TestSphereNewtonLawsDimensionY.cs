// Copyright Gary Evans 2006.

using System;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Runs the dimension specific tests in the y dimension.
    /// </summary>
    [TestFixture]
    public class TestSphereNewtonLawsDimensionY
        : TestSphereNewtonLawsDimensionSpecific
    {
        /// <summary>
        /// Default constructor. Sets the vectorAxis to the y
        /// dimension.
        /// </summary>
        public TestSphereNewtonLawsDimensionY()
        {
            VectorAxis = 1;
        }
    }
}
