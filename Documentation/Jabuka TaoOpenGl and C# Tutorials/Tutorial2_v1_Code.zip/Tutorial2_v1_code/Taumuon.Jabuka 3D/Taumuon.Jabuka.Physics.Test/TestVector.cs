// Copyright Gary Evans 2006.

using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Tests the operation of the Vector class.
    /// </summary>
    [TestFixture]
    public class TestVector
    {
        /// <summary>
        /// Tests the addition of two vectors.
        /// </summary>
        [Test]
        public void TestVectorAddition()
        {
            Vector vector1 = new Vector(1.0, 2.0, 3.0);
            Vector vector2 = new Vector(-2.0, 1.0, 1.0);
            Vector vector3 = vector1 + vector2;
            // Check that the original vectors are unchanged
            //  following addition
            Assert.AreEqual(vector1.X, 1.0);
            Assert.AreEqual(vector1.Y, 2.0);
            Assert.AreEqual(vector1.Z, 3.0);
            Assert.AreEqual(vector2.X, -2.0);
            Assert.AreEqual(vector2.Y, 1.0);
            Assert.AreEqual(vector2.Z, 1.0);
            // Check the result of addition
            Assert.AreEqual(vector3.X, -1.0);
            Assert.AreEqual(vector3.Y, 3.0);
            Assert.AreEqual(vector3.Z, 4.0);
        }

        /// <summary>
        /// Tests the multiplication of a Vector by a scalar.
        /// </summary>
        [Test]
        public void TestVectorMultiplyByScalar()
        {
            Vector vector1 = new Vector(1.0, 2.0, 3.0);
            Vector vector2 = vector1 * 2.0;
            // Check that the original vector is unchanged
            //  following multiplication by a scalar
            Assert.AreEqual(vector1.X, 1.0);
            Assert.AreEqual(vector1.Y, 2.0);
            Assert.AreEqual(vector1.Z, 3.0);
            // Check the result of multiplication by a scalar
            Assert.AreEqual(vector2.X, 2.0);
            Assert.AreEqual(vector2.Y, 4.0);
            Assert.AreEqual(vector2.Z, 6.0);
        }
    }
}
