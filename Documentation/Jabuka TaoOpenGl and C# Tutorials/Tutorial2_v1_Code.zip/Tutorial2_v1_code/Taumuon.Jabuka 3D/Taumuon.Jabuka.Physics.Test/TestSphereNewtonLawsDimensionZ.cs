// Copyright Gary Evans 2006.

using System;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Runs the dimension specific tests in the y dimension.
    /// </summary>
    [TestFixture]
    public class TestSphereNewtonLawsDimensionZ
        : TestSphereNewtonLawsDimensionSpecific
    {
        /// <summary>
        /// Default constructor. Sets the vectorAxis to the z
        /// dimension.
        /// </summary>
        public TestSphereNewtonLawsDimensionZ()
        {
            VectorAxis = 2;
        }
    }
}
