// Copyright Gary Evans 2006.

using System;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Tests that are dimension specific.
    /// The contained test cases will be ran for the three
    /// dimensions.
    /// </summary>
    public class TestSphereNewtonLawsDimensionSpecific
    {
        #region Private Member Variables

        private int vectorAxis = 0;

        #endregion Private Member Variables

        #region Test Methods

        /// <summary>
        /// Tests that a sphere initially at rest remains at rest.
        /// </summary>
        [Test]
        public void TestRemainsAtRest()
        {
            Sphere sphere = CreateSphere(0.0, 0.0);
            UpdateSphereAndCheckState(sphere, 0.0, 0.0, 0.0, 1);
        }

        /// <summary>
        /// Tests that a sphere with a non-zero initial velocity
        /// moves with a constant velocity.
        /// </summary>
        [Test]
        public void TestNoForceVelocityRemainsConstant()
        {
            Sphere sphere = CreateSphere(0.0, 0.5);
            UpdateSphereAndCheckState(sphere, 0.5, 5.0, 0.0, 1);
        }

        /// <summary>
        /// Tests that a sphere subject to a constant applied
        /// force updates its location and velocity.
        /// </summary>
        [Test]
        public void TestForceVelocityAndLocationChange()
        {
            Sphere sphere = CreateSphere(0.0, 0.0);
            UpdateSphereAndCheckState(sphere, 10.0, 50.0499999999,
                1.0, 1000);
        }

        /// <summary>
        /// Tests that a sphere subject to a constant applied
        /// force updates its location and velocity, with a mass
        /// of two kilograms.
        /// </summary>
        [Test]
        public void TestForceMassTwoKilograms()
        {
            Sphere sphere = CreateSphere(0.0, 0.0, 2.0);
            UpdateSphereAndCheckState(sphere, 5.0, 25.0249999999,
                1.0, 1000);
        }

        /// <summary>
        /// Tests that a sphere subject to a constant applied
        /// force updates its location and velocity, with a mass
        /// of two kilograms, and non-zero initial velocity.
        /// </summary>
        [Test]
        public void TestMassTwoKilogramsNonZeroLocation()
        {
            Sphere sphere = CreateSphere(-5.0, 0.0, 2.0);
            UpdateSphereAndCheckState(sphere, 5.0, 20.0249999999,
                1.0, 1000);
        }

        /// <summary>
        /// Tests that a sphere subject to a constant applied
        /// force updates its location and velocity, with a mass
        /// of two kilograms, and non-zero initial velocity.
        /// This test is against the Y dimension.
        /// </summary>
        // [Test]
        public void TestMassTwoKilogramsNonZeroLocationYDimension()
        {
            Vector location = new Vector(0.0, -5.0, 0.0);
            Vector velocity = new Vector(0.0, 0.0, 0.0);
            Sphere sphere = new Sphere(location, velocity, 2.0);

            double expectedVelocity = 5.0;
            double expectedLocation = 20.0249999999;
            double appliedForce = 1.0;
            int numberOfIterations = 1000;

            const double time = 10.0;
            sphere.ApplyForce(new Vector(0.0, appliedForce, 0.0));
            for (int i = 1; i <= numberOfIterations; ++i)
            {
                sphere.Update(time / numberOfIterations);
            }
            const double tolerance = 1e-10;
            Assert.AreEqual(expectedVelocity, sphere.Velocity.Y,
                tolerance, "Velocity not as expected");
            Assert.AreEqual(expectedLocation, sphere.Location.Y,
                tolerance, "Location not as expected");
        }

        #endregion Test Methods

        #region Helper Methods

        /// <summary>
        /// Retrieves the value stored in the current fixture's
        ///  dimension out of the provided Vector.
        /// </summary>
        private double GetVectorValue(Vector vector, int dimension)
        {
            switch (dimension)
            {
                case 0 :
                    return vector.X;
                case 1 :
                    return vector.Y;
                case 2 :
                    return vector.Z;
                default :
                    throw new ApplicationException
                        ("Unrecognised dimension: " + 
                        dimension.ToString());
             }
        }

        /// <summary>
        /// Stores the value into the Vector given fixture's
        /// current dimension.
        /// </summary>
        private void SetVectorValue(Vector vector, int dimension,
            double value)
        {
            switch (dimension)
            {
                case 0:
                    vector.X = value;
                    break;
                case 1:
                    vector.Y = value;
                    break;
                case 2:
                    vector.Z = value;
                    break;
                default:
                    throw new ApplicationException
                        ("Unrecognised dimension: " +
                        dimension.ToString());
            }
        }

        /// <summary>
        /// Creates a sphere with a default mass of 1kg.
        /// </summary>
        /// <param name="location">The initial location</param>
        /// <param name="velocity">The initial velocity</param>
        /// <returns>A new sphere</returns>
        private Sphere CreateSphere(double location, double velocity)
        {
            return CreateSphere(location, velocity, 1.0);
        }

        /// <summary>
        /// Creates a sphere.
        /// </summary>
        /// <param name="location">The initial location</param>
        /// <param name="velocity">The initial velocity</param>
        /// <param name="mass">The sphere's mass</param>
        /// <returns>A new sphere</returns>
        private Sphere CreateSphere(double location,
            double velocity, double mass)
        {
            Vector locationVector = new Vector(0.0, 0.0, 0.0);
            SetVectorValue(locationVector, vectorAxis, location);
            Vector velocityVector = new Vector(0.0, 0.0, 0.0);
            SetVectorValue(velocityVector, vectorAxis, velocity);
            return new Sphere(locationVector, velocityVector, mass);
        }

        private void UpdateSphereAndCheckState(Sphere sphere,
            double expectedVelocity, double expectedLocation,
            double appliedForce, int numberOfIterations)
        {
            const double time = 10.0;
            Vector force = new Vector(0.0, 0.0, 0.0);
            SetVectorValue(force, vectorAxis, appliedForce);
            sphere.ApplyForce(force);
            for (int i = 1; i <= numberOfIterations; ++i)
            {
                sphere.Update(time / numberOfIterations);
            }
            const double tolerance = 1e-10;
            Assert.AreEqual(expectedVelocity,
                GetVectorValue(sphere.Velocity, vectorAxis),
                tolerance, "Velocity not as expected");
            Assert.AreEqual(expectedLocation,
                GetVectorValue(sphere.Location, vectorAxis),
                tolerance, "Location not as expected");
        }

        #endregion Helper Methods

        #region Protected Accessors

        /// <summary>
        /// Sets the current dimension for the test fixture.
        /// </summary>
        protected int VectorAxis
        {
            set
            {
                vectorAxis = value;
            }
        }

        #endregion Protected Accessors
    }
}
