// Copyright Gary Evans 2006.

using System;

using Taumuon.Jabuka.Physics;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Tests that a sphere moves according to Newton's
    /// laws of motion.
    /// </summary>
    [TestFixture]
    public class TestSphereNewtonLaws
    {
        #region Test Methods

        /// <summary>
        /// Tests that a sphere with zero mass can't be created.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException),
            "mass cannot be zero")]
        public void TestCreateASphereWithZeroMass()
        {
            Sphere sphere = new Sphere(new Vector(0.0, 0.0, 0.0),
                new Vector(0.0, 0.0, 0.0), 0.0);
        }

        /// <summary>
        /// Tests that a sphere with zero location can't be created.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException),
@"Value cannot be null.
Parameter name: location")]
        public void TestCreateASphereWithNullLocation()
        {
            Sphere sphere = new Sphere(null,
                new Vector(0.0, 0.0, 0.0), 1.0);
        }

        /// <summary>
        /// Tests that a sphere with zero velocity can't be created.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException),
@"Value cannot be null.
Parameter name: velocity")]
        public void TestCreateASphereWithNullVelocity()
        {
            Sphere sphere = new Sphere( new Vector(0.0, 0.0, 0.0),
                null, 1.0);
        }

        #endregion Test Methods
    }
}
