// Copyright Gary Evans 2006.

using System;
using System.Windows.Forms;

using Tao.OpenGl;

namespace Taumuon.Jabuka.MainApp
{
    public partial class Form1 : Form
    {
        #region Member Variables

        private World world = null;

        #endregion

        /// <summary>
        /// The Application's main form.
        /// </summary>
        public Form1(World world)
        {
            if (null == world)
            {
                throw new ArgumentNullException("world");
            }

            InitializeComponent();
            this.simpleOpenGlControl1.InitializeContexts();

            this.world = world;

            world.InitGl();
            world.SetView(this.Height, this.Width);
        }

        /// <summary>
        /// Handles the resizing of the form.
        /// </summary>
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            world.SetView(this.Height, this.Width);
        }

        private void simpleOpenGlControl1_Paint(object sender,
                                                PaintEventArgs e)
        {
            world.RenderScene();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            world.UpdateLocations();
            this.Refresh();
        }
    }
}