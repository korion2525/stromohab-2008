// Copyright Gary Evans 2006.

using System;

using Tao.OpenGl;

namespace Taumuon.Jabuka.MainApp
{
    class Axes : IDrawable
    {
        #region Member Variables

        private double axesYLocation = 0.0;

        #endregion Member Variables

        public void Draw()
        {
            Gl.glPushMatrix();
            Gl.glTranslated(0.0, axesYLocation, 0.0);

            const float axisSize = 25.0f;

            // draw a line along the z-axis
            Gl.glColor3f(1.0f, 0.0f, 0.0f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3f(0.0f, 0.0f, -axisSize);
            Gl.glVertex3f(0.0f, 0.0f, axisSize);
            Gl.glEnd();

            // draw a line along the y-axis
            Gl.glColor3f(0.0f, 1.0f, 0.0f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3f(0.0f, -axisSize, 0.0f);
            Gl.glVertex3f(0.0f, axisSize, 0.0f);
            Gl.glEnd();

            // draw a line along the x-axis
            Gl.glColor3f(0.0f, 0.0f, 1.0f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3f(-axisSize, 0.0f, 0.0f);
            Gl.glVertex3f(axisSize, 0.0f, 0.0f);
            Gl.glEnd();

            Gl.glPopMatrix();
        }

        /// <summary>
        /// The object updates its location by the given increment.
        /// </summary>
        public void Update(double increment)
        {
            this.axesYLocation += increment;
        }
    }
}
