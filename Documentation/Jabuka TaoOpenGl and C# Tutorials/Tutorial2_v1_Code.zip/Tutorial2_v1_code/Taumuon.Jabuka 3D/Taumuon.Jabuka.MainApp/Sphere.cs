// Copyright Gary Evans 2006.

using System;

using Tao.OpenGl;

namespace Taumuon.Jabuka.MainApp
{
    class Sphere : IDrawable
    {
        #region Member Variables

        private double sphereZLocation = 0.0;

        #endregion Member Variables

        public void Draw()
        {
            Gl.glPushMatrix();
            Gl.glTranslated(0.0, 0.0, sphereZLocation);

            bool drawWireFrame = false;
            int drawStyle = drawWireFrame ? Glu.GLU_LINE :
                                                  Glu.GLU_FILL;

            double radius = 5.0;

            // From NeHe lesson 18.
            Glu.GLUquadric quadric = Glu.gluNewQuadric();
            try
            {
                Glu.gluQuadricDrawStyle(quadric, drawStyle);
                Glu.gluQuadricNormals(quadric, Glu.GLU_SMOOTH);
                Glu.gluSphere(quadric, radius, 40, 40);
            }
            finally
            {
                Glu.gluDeleteQuadric(quadric);
            }

            Gl.glPopMatrix();
        }

        /// <summary>
        /// The object updates its location by the given increment.
        /// </summary>
        public void Update(double increment)
        {
            this.sphereZLocation += increment;
        }
    }
}
