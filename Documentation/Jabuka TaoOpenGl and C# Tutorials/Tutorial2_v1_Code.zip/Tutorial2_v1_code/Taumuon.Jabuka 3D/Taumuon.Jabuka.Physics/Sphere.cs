// Copyright Gary Evans 2006.

using System;

namespace Taumuon.Jabuka.Physics
{
    /// <summary>
    /// A physical sphere.
    /// </summary>
    public class Sphere
    {
        #region Member Variables

        private Vector location = null;
        private Vector velocity = null;
        private Vector force = null;
        private double mass = 0.0;

        #endregion Member Variables

        #region Object Lifetime

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="location">Initial location.</param>
        /// <param name="velocity">Initial velocity.</param>
        /// <param name="mass">The sphere's mass.</param>
        public Sphere(Vector location, Vector velocity, double mass)
        {
            if (mass == 0.0)
            {
                throw new ArgumentException("mass cannot be zero");
            }
            if (location == null)
            {
                throw new ArgumentNullException(
                    "location");
            }
            if (velocity == null)
            {
                throw new ArgumentNullException(
                    "velocity");
            }
            this.location = location;
            this.velocity = velocity;
            this.mass = mass;
        }

        #endregion Object Lifetime

        #region Public Accessors

        /// <summary>
        /// Retrieves the current location.
        /// </summary>
        public Vector Location
        {
            get
            {
                return this.location;
            }
        }

        /// <summary>
        /// Retrieves the current velocity.
        /// </summary>
        public Vector Velocity
        {
            get
            {
                return this.velocity;
            }
        }

        #endregion Public Accessors

        #region Public Methods

        /// <summary>
        /// Allows the sphere to update its physical state.
        /// </summary>
        /// <param name="deltaTime">Time increment, in seconds.</param>
        public void Update(double deltaTime)
        {
            Vector acceleration = new Vector(this.force.X / mass,
                this.force.Y / mass, this.force.Z / mass );
            this.velocity += acceleration * deltaTime;
            this.location += this.velocity * deltaTime;
        }

        /// <summary>
        /// Applies a force to the sphere.
        /// </summary>
        /// <param name="force">Force, in Newtons.</param>
        public void ApplyForce(Vector force)
        {
            this.force = force;
        }

        #endregion Public Methods
    }
}
