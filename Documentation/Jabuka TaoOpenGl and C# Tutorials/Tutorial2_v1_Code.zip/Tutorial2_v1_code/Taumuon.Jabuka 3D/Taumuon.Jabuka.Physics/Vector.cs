// Copyright Gary Evans 2006.

using System;
using System.Collections.Generic;
using System.Text;

namespace Taumuon.Jabuka.Physics
{
    /// <summary>
    /// Represents a Vector in 3 dimensions.
    /// Can represent a point, or a vector from the origin.
    /// </summary>
    public class Vector
    {
        #region Private Member Variables

        private double x = 0.0;
        private double y = 0.0;
        private double z = 0.0;

        #endregion Private Member Variables

        #region Object Lifetime

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="x">Initial x location</param>
        /// <param name="y">Initial y location</param>
        /// <param name="z">Initial z location</param>
        public Vector(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        #endregion Object Lifetime

        #region Accessors

        /// <summary>
        /// Returns the vector's X dimension value.
        /// </summary>
        public double X
        {
            get { return x; }
            set { x = value; }
        }

        /// <summary>
        /// Returns the vector's X dimension value.
        /// </summary>
        public double Y
        {
            get { return y; }
            set { y = value; }
        }

        /// <summary>
        /// Returns the vector's Z dimension value.
        /// </summary>
        public double Z
        {
            get { return z; }
            set { z = value; }
        }

        #endregion Accessors

        #region Operators

        /// <summary>
        /// Overloaded addition operator
        /// </summary>
        /// <param name="lhs">The left-hand operand</param>
        /// <param name="rhs">The right-hand operand</param>
        /// <returns>
        /// Result of addition, leaving the operands unchanged.
        /// </returns>
        public static Vector operator +(Vector lhs, Vector rhs)
        {
            return new Vector(lhs.X + rhs.X, lhs.Y + rhs.Y,
                                                lhs.Z + rhs.Z);
        }

        /// <summary>
        /// Overloaded multiplication operator, for a vector and
        /// a scalar.
        /// </summary>
        /// <param name="lhs">The left-hand operand</param>
        /// <param name="rhs">The right-hand operand</param>
        /// <returns>
        /// Result of multiplication, leaving operands unchanged.
        /// </returns>
        public static Vector operator *(Vector lhs, double rhs)
        {
            return new Vector(lhs.X * rhs, lhs.Y * rhs, lhs.Z * rhs);
        }

        #endregion Operators
    }
}
