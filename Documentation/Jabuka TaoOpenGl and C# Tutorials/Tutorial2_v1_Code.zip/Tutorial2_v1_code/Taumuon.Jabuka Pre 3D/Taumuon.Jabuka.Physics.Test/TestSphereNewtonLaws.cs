// Copyright Gary Evans 2006.

using System;

using Taumuon.Jabuka.Physics;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Tests that a sphere moves according to Newton's
    /// laws of motion.
    /// </summary>
    [TestFixture]
    public class TestSphereNewtonLaws
    {
        #region Test Methods

        /// <summary>
        /// Tests that a sphere initially at rest remains at rest.
        /// </summary>
        [Test]
        public void TestRemainsAtRest()
        {
            Sphere sphere = CreateSphere(0.0, 0.0);
            UpdateSphereAndCheckState(sphere, 0.0, 0.0, 0.0, 1);
        }

        /// <summary>
        /// Tests that a sphere with a non-zero initial velocity
        /// moves with a constant velocity.
        /// </summary>
        [Test]
        public void TestNoForceVelocityRemainsConstant()
        {
            Sphere sphere = CreateSphere(0.0, 0.5);
            UpdateSphereAndCheckState(sphere, 0.5, 5.0, 0.0, 1);
        }

        /// <summary>
        /// Tests that a sphere subject to a constant applied
        /// force updates its location and velocity.
        /// </summary>
        [Test]
        public void TestForceVelocityAndLocationChange()
        {
            Sphere sphere = CreateSphere(0.0, 0.0);
            UpdateSphereAndCheckState(sphere, 10.0, 50.0499999999,
                1.0, 1000);
        }

        /// <summary>
        /// Tests that a sphere subject to a constant applied
        /// force updates its location and velocity, with a mass
        /// of two kilograms.
        /// </summary>
        [Test]
        public void TestForceMassTwoKilograms()
        {
            Sphere sphere = CreateSphere(0.0, 0.0, 2.0);
            UpdateSphereAndCheckState(sphere, 5.0, 25.0249999999,
                1.0, 1000);
        }

        /// <summary>
        /// Tests that a sphere with zero mass can't be created.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException),
            "mass cannot be null")]
        public void TestCreateASphereWithZeroMass()
        {
            Sphere sphere = CreateSphere(0.0, 0.0, 0.0);
        }

        #endregion Test Methods

        #region Helper Methods

        /// <summary>
        /// Creates a sphere with a default mass of 1kg.
        /// </summary>
        /// <param name="location">The initial location</param>
        /// <param name="velocity">The initial velocity</param>
        /// <returns>A new sphere</returns>
        private Sphere CreateSphere(double location, double velocity)
        {
            return CreateSphere(location, velocity, 1.0);
        }

        /// <summary>
        /// Creates a sphere.
        /// </summary>
        /// <param name="location">The initial location</param>
        /// <param name="velocity">The initial velocity</param>
        /// <param name="mass">The sphere's mass</param>
        /// <returns>A new sphere</returns>
        private Sphere CreateSphere(double location,
            double velocity, double mass)
        {
            return new Sphere(location, velocity, mass);
        }

        private void UpdateSphereAndCheckState(Sphere sphere,
            double expectedVelocity, double expectedLocation,
            double appliedForce, int numberOfIterations)
        {
            const double time = 10.0;
            sphere.ApplyForce(appliedForce);
            for (int i = 1; i <= numberOfIterations; ++i)
            {
                sphere.Update(time / numberOfIterations);
            }
            const double tolerance = 1e-10;
            Assert.AreEqual(expectedVelocity, sphere.Velocity,
                tolerance, "Velocity not as expected");
            Assert.AreEqual(expectedLocation, sphere.Location,
                tolerance, "Location not as expected");
        }

        #endregion Helper Methods
    }
}
