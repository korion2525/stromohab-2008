To build this version 1.3 of the Tao Framework should be downloaded from http://www.taoframework.com/Downloads.

When building this project, the references point to a Dependencies folder being present two folders below the solution folder:

SomeFolder
  \Dependencies
  \SomeOtherFolder
    \Taumuon.Jabuka
     Taumuon.Jabuka.sln

Make sure that the Dependencies folder contains the Tao dlls, or change the references in the project to point to where these are located.

To build the NUnit project change the references in that project to the install location of the NUnit assemblies.
Alternatively (if you aren't concerned with unit testing), remove the project from the solution.