// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace Taumuon.Jabuka.Physics.Collision
{
    using CollisionsByType = Dictionary<CollisionType, List<CollisionManager.Collision>>;

    /// <summary>
    /// Handles updating the objects, checking for collisions between them,
    ///  and performing collision response.
    /// </summary>
    public class CollisionManager
    {
        #region Object Lifetime

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="spheres">The list of spheres that will be updated, 
        /// and subsequently checked for any collisions.</param>
        public CollisionManager(List<Sphere> spheres)
        {
            if (spheres == null)
            {
                throw new ArgumentNullException("spheres");
            }

			this.spheres = spheres;
        }

        #endregion Object Lifetime

		#region Public Methods

        /// <summary>
        /// Updates all of the objects that the collision manager owns.
        /// </summary>
        /// <param name="deltaTime">Time increment, in seconds.</param>
        public void Update(double deltaTime)
        {
            Dictionary<Sphere, Sphere> cloneDictionary = new Dictionary<Sphere, Sphere>(spheres.Count);
            List<Sphere> clones = new List<Sphere>(spheres.Count);
            CollisionsByType collisions = null;

            CloneSpheres(cloneDictionary, this.spheres, clones);

            UpdateSpheres(clones, deltaTime);
            collisions = CheckForCollisions(clones);

            double timeOfCollision = 0.0;
            if (collisions.ContainsKey(CollisionType.Intersection))
            {
                List<Sphere> intersectingSpheres = new List<Sphere>();
                foreach (Collision collision in collisions[CollisionType.Intersection])
                {
                    Sphere originalSphere1 = cloneDictionary[collision.Sphere1];
                    Sphere originalSphere2 = cloneDictionary[collision.Sphere2];

                    if (!intersectingSpheres.Contains(originalSphere1))
                    {
                        intersectingSpheres.Add(originalSphere1);
                    }
                    if (!intersectingSpheres.Contains(originalSphere2))
                    {
                        intersectingSpheres.Add(originalSphere2);
                    }
                }
                timeOfCollision = GetTimeOfCollision(deltaTime, intersectingSpheres);

                // Reset the cloned spheres from the original set of spheres, then
                //  Update the spheres with the updated time.
                CloneSpheres(cloneDictionary, this.spheres, clones);
                UpdateSpheres(clones, timeOfCollision);
                collisions = CheckForCollisions(clones);
            }

            if (collisions.ContainsKey(CollisionType.Intersection))
            {
                // The exact time of intersection wasn't found within the number of intersections.
                foreach (Collision collision in collisions[CollisionType.Intersection])
                {
                    DoCollisionResponse(collision.Sphere1, collision.Sphere2);
                }
            }

            if (collisions.ContainsKey(CollisionType.Collision))
            {
                foreach (Collision collision in collisions[CollisionType.Collision])
                {
                    DoCollisionResponse(collision.Sphere1, collision.Sphere2);
                }
            }

            UpdateOriginalSpheresFromClones(cloneDictionary, clones);

            // We have now updated the location of the original spheres to that of the clones.
            //  If there was an intersection then we've only updated to the time of collision,
            //  we need to Update with the remaining time.
            if (timeOfCollision > 0.0)
            {
                Update(deltaTime - timeOfCollision);
            }
        }

        /// <summary>
        /// Returns the time of collision of a set of objects that intersects in a certain
        ///  time interval. Updates the spheres, bisecting the interval to find the time of
        ///  collision of the spheres that were intersecting at the end of the interval.
        /// </summary>
        /// <param name="deltaTime">The external interval time.</param>
        /// <param name="intersectingSpheres">
        /// The list of original spheres that were intersecting at the end of the interval.
        /// </param>
        /// <returns>The exact time of collision.</returns>
        private double GetTimeOfCollision(double deltaTime, List<Sphere> intersectingSpheres)
        {
            Dictionary<Sphere, Sphere> cloneDictionary = new Dictionary<Sphere, Sphere>();
            List<Sphere> clones = new List<Sphere>(intersectingSpheres.Count);
            CollisionsByType collisions = null;

            bool searchForIntersection = true;
            double latestNonIntersectingTime = 0.0;
            double currentBisectionTime = 0.0;
            double currentTime = deltaTime;
            const int totalnumIterations = 8;
            int numIterations = 0;
            List<Collision> intersections = null;
            while (searchForIntersection && (numIterations++ < totalnumIterations))
            {
                currentBisectionTime = deltaTime / (Math.Pow(2.0, numIterations));
                CloneSpheres(cloneDictionary, intersectingSpheres, clones);

                UpdateSpheres(clones, currentTime);
                collisions = CheckForCollisions(clones);

                if (collisions.ContainsKey(CollisionType.Intersection))
                {
                    Debug.Assert(collisions.Count > 0, "Should be intersections if present in dictionary");
                    searchForIntersection = true;

                    // Replace the last set of intersections, if any, as we may have hit an earlier
                    //  intersection (may be more than 1 intersection in our time step).
                    intersections = collisions[CollisionType.Intersection];
                    currentTime = latestNonIntersectingTime + currentBisectionTime;
                }
                else
                {
                    if (numIterations > 1)
                    {
                        // This indicates that even though we're not currently intersecting, that
                        //  there has been a previous intersection on a previous iteration
                        // We want to check whether there are collisions corresponding on the 
                        //  previous interesections, and if not we want to narrow in on the time
                        //  of collision.

                        if (collisions.ContainsKey(CollisionType.Collision)
                            && intersections.Count == collisions[CollisionType.Collision].Count)
                        {
                            // NOTE: This is the actual time of collision that caused the previous intersections
                            //   on a previous intersection
                            searchForIntersection = false;
                        }
                        else
                        {
                            searchForIntersection = true;

                            latestNonIntersectingTime = currentTime;
                            currentTime += currentBisectionTime;
                        }
                    }
                    else
                    {
                        searchForIntersection = false;
                    }
                }
            }
            return currentTime;
        }

        /// <summary>
        /// Populates the list of clones and the clonedictionary from the list of spheres.
        /// </summary>
        /// <param name="cloneDictionary">Keyed on the clone, with the value being the original uncloned sphere.</param>
        /// <param name="originalSpheres">The list of original spheres.</param>
        /// <param name="clones">The list of clones.</param>
        private void CloneSpheres(Dictionary<Sphere, Sphere> cloneDictionary,
            List<Sphere> originalSpheres, List<Sphere> clones)
        {
            clones.Clear();
            cloneDictionary.Clear();

            foreach (Sphere sphere in originalSpheres)
            {
                Sphere clone = (Sphere)sphere.Clone();
                cloneDictionary.Add(clone, sphere);
                clones.Add(clone);
            }
        }

		/// <summary>
		/// Updates the original sphere properties to match the updated properties on the clones.
		/// </summary>
		private void UpdateOriginalSpheresFromClones(Dictionary<Sphere, Sphere> cloneDictionary,
			List<Sphere> clones)
		{
			foreach (Sphere clone in clones)
			{
				cloneDictionary[clone].AssignFromSphere(clone);
			}
		}

		/// <summary>
		/// Calls the Update() property on the spheres to allow them to update their physical state.
		/// </summary>
		/// <param name="spheres">The list of spheres to update.</param>
		/// <param name="deltaTime">The time increment to update the spheres by.</param>
		private void UpdateSpheres(List<Sphere> spheres, double deltaTime)
		{
			foreach (Sphere sphere in spheres)
			{
				sphere.EulerRigidBody.Update(deltaTime);
			}
		}

		private CollisionsByType CheckForCollisions(List<Sphere> clones)
		{
			CollisionsByType collisions = new CollisionsByType();
			for (int outerLoopCount = 0; outerLoopCount < clones.Count; ++outerLoopCount)
			{
				for (int innerLoopCount = outerLoopCount + 1; innerLoopCount < clones.Count; ++innerLoopCount)
				{
					CollisionType result = clones[outerLoopCount].CheckForCollision(clones[innerLoopCount]);
					switch( result )
					{
						case CollisionType.None :
							break;
						case CollisionType.Collision :
                            AddCollisionToDictionary(collisions, result, clones[outerLoopCount], clones[innerLoopCount]);
							break;
						case CollisionType.ForcedContact:
						case CollisionType.TouchingContact:
                            break;
						case CollisionType.Intersection:
                            // NOTE: without checking whether the objects are separating away from each other,
                            //  this would get us stuck in infinite recursion in UpdateSpheres().
                            //  The DoCollisionResponse() sets the velocities of the intersection objects
                            //  away from each other, but if these objects don't move far enough away in the
                            //  next recursive call's time step then they still report as intersecting
                            // (the intersecting test in this case needs to check whether they're moving away
                            // from each other.

                            // The spheres are within touching distance
                            // See whether they're moving towards each other.
                            // relative velocity of the other body with respect to us.
                            Vector vectorOuterTowardsInner =
                                clones[outerLoopCount].EulerRigidBody.Location - clones[innerLoopCount].EulerRigidBody.Location;
                            Vector relativeVelocity = clones[outerLoopCount].EulerRigidBody.Velocity
                                - clones[innerLoopCount].EulerRigidBody.Velocity;
                            double speedTowards = vectorOuterTowardsInner.DotProduct(relativeVelocity);
                            // The check that the sphere is moving towards us is so that we
                            //  don't keep reporting an intersection if the collision response has
                            //  happened as the sphere may not have moved far enough away to report
                            //  non-intersecting.
                            //  The check for the relative velocity being zero is for the case where
                            //   e.g. the spheres may have intersected, then the velocity transferred to
                            //   the second sphere, which then transfers it to a third sphere (a la Newton's cradle)
                            //   leaving the second embedded in the first. We don't want this to be reported
                            //   as an intersection as collision response won't do anything.
                            if (!MathUtils.IsEqualWithinTol(speedTowards, 0.0, 1e-10)
                                && speedTowards < 0)
                            {
                                AddCollisionToDictionary(collisions, result, clones[outerLoopCount], clones[innerLoopCount]);
                            }
							break;
						default :
							Debug.Assert(false, "Enum value not recognised");
							break;
					}
				}
			}
			return collisions;
		}

        /// <summary>
        /// Adds a collision to the dictionary.
        /// </summary>
        private void AddCollisionToDictionary(CollisionsByType collisions, CollisionType result, Sphere sphere1, Sphere sphere2)
        {
            if (!collisions.ContainsKey(result))
            {
                collisions.Add(result, new List<Collision>());
            }
            collisions[result].Add(new Collision(result, sphere1, sphere2));
        }

		/// <summary>
		/// Performs an inelastic collision between the two spheres, updates their velocities
		///  conserving momentum and kinetic energy.
		/// </summary>
		/// <param name="sphere1"></param>
		/// <param name="sphere2"></param>
		public static void DoCollisionResponse(Sphere sphere1, Sphere sphere2)
		{
			Vector vectorBetweenSphereCentres =
				sphere2.EulerRigidBody.Location	- sphere1.EulerRigidBody.Location;

			Vector normalisedVectorBetweenSphereCentres = vectorBetweenSphereCentres.Normalise();

			double velocityComponentParallelCentresSphere1 = normalisedVectorBetweenSphereCentres.DotProduct(sphere1.EulerRigidBody.Velocity);
			Vector velocityAlongCentresSphere1 = normalisedVectorBetweenSphereCentres * velocityComponentParallelCentresSphere1;
			Vector velocityPerpendicularToCentresSphere1 = sphere1.EulerRigidBody.Velocity - velocityAlongCentresSphere1;

			double velocityComponentParallelCentresSphere2 = normalisedVectorBetweenSphereCentres.DotProduct(sphere2.EulerRigidBody.Velocity);
			Vector velocityAlongCentresSphere2 = normalisedVectorBetweenSphereCentres * velocityComponentParallelCentresSphere2;
            Vector velocityPerpendicularToCentresSphere2 = sphere2.EulerRigidBody.Velocity - velocityAlongCentresSphere2;

            double finalVelocity1;
            double finalVelocity2;

			ResolveVelocities(velocityComponentParallelCentresSphere1, velocityComponentParallelCentresSphere2,
				sphere1.EulerRigidBody.Mass, sphere2.EulerRigidBody.Mass, out finalVelocity1, out finalVelocity2);
			
			Vector velocityBody1 = velocityPerpendicularToCentresSphere1 + (normalisedVectorBetweenSphereCentres * finalVelocity1);
			sphere1.EulerRigidBody.Velocity.SetValues( velocityBody1.X, velocityBody1.Y, velocityBody1.Z);
			Vector velocityBody2 = velocityPerpendicularToCentresSphere2 + (normalisedVectorBetweenSphereCentres * finalVelocity2);
			sphere2.EulerRigidBody.Velocity.SetValues(velocityBody2.X, velocityBody2.Y, velocityBody2.Z);
		}

        /// <summary>
        /// Resolves the collision velocities.
        ///  These are the components of the velocities along the line of collision.
        /// </summary>
        private static void ResolveVelocities(double initialVelocity1, double initialVelocity2,
            double mass1, double mass2, out double finalVelocity1, out double finalVelocity2)
        {
			// from http://www.euclideanspace.com/physics/dynamics/collision/oned/index.htm
            //final velocity of object a
            //vaf = ( vai * ( ( ma � mb )/ (ma + mb) ) ) + ( vbi * ( 2 * mb) / (ma + mb) ))
            //final velocity of object b
            //vbf = ( vai * ( 2*ma) / (ma + mb) )  -  ( vbi * (ma-mb) / (ma+mb) )

			if (double.IsPositiveInfinity(mass1))
			{
				finalVelocity1 = initialVelocity1;
				finalVelocity2 = -initialVelocity2;
			}
			else if (double.IsPositiveInfinity(mass2))
			{
				finalVelocity1 = -initialVelocity1;
				finalVelocity2 = initialVelocity2;
			}
			else
			{
				double sumOfMasses = mass1 + mass2;
				double ratioOfMassDifference = (mass1 - mass2) / sumOfMasses;
				finalVelocity1 = (initialVelocity1 * ratioOfMassDifference)
				+ (initialVelocity2 * (2 * mass2 / sumOfMasses));
				finalVelocity2 = (initialVelocity1 * 2 * mass1 / sumOfMasses)
				- (initialVelocity2 * ratioOfMassDifference);
			}
        }

		#endregion Public Methods

        #region Member Variables

        private List<Sphere> spheres;

        #endregion Member Variables

		#region Nested Types

		internal class Collision
		{
			public Collision(CollisionType type, Sphere sphere1, Sphere sphere2)
			{
                // NOTE: only assert as this class is internal.
                Debug.Assert(sphere1 != null, "sphere1 should not be null");
                Debug.Assert(sphere2 != null, "sphere2 should not be null");
				this.type = type;
				this.sphere1 = sphere1;
				this.sphere2 = sphere2;
			}

			public CollisionType CollisionType
			{
				get { return this.type; }
			}

			public Sphere Sphere1
			{
				get { return this.sphere1; }
			}

			public Sphere Sphere2
			{
				get { return this.sphere2; }
			}

			private CollisionType type = CollisionType.None;
			private Sphere sphere1 = null;
			private Sphere sphere2 = null;
		}

		#endregion Nested Types
	}
}
