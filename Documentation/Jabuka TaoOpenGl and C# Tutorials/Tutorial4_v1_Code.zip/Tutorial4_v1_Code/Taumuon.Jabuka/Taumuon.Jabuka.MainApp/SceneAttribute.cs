// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Attribute used to identity and describe a scene.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class SceneAttribute : Attribute
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="title">The Scene's title.</param>
        /// <param name="description">The description of the scene.</param>
        public SceneAttribute(string title, string description)
        {
            this.title = title;
            this.description = description;
        }

        /// <summary>
        /// The Scene's title.
        /// </summary>
        public string Title
        {
            get
            {
                return this.title;
            }
        }

        /// <summary>
        /// The description of the scene.
        /// </summary>
        public string Description
        {
            get
            {
                return this.description;
            }
        }

        private string title;
        private string description;
    }
}
