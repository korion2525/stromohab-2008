// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            List<SceneDescription> sceneDescriptions = SceneFinder.GetSceneDescriptions();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainOpenGlForm(sceneDescriptions));
        }
    }
}