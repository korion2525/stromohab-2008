// Copyright Gary Evans 2006-2007.

using System;

using Tao.OpenGl;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    class Sphere : IDrawable
    {
        #region Object Lifetime

        /// <summary>
        /// Construct a drawable Sphere.
        /// </summary>
        /// <param name="eulerRigidBody">
        /// The rigid body that is used to obtain the
        ///  Sphere's location.
        /// </param>
        /// <param name="radius">The Sphere's radius.</param>
        /// <param name="colour">The colour to use to draw the sphere.</param>
        /// <exception cref="ArgumentNullException"/>
        public Sphere(EulerRigidBody eulerRigidBody, double radius,
            Colour colour)
        {
            if (eulerRigidBody == null)
            {
                throw new ArgumentNullException("eulerRigidBody");
            }
            this.eulerRigidBody = eulerRigidBody;
            if (radius < 0.0)
            {
                throw new ArgumentException("Value must not be negative", "radius");
            }
            this.radius = radius;
            this.colour = colour;
        }

        #endregion Object Lifetime

        #region IDrawable Implementation

        public void Draw()
        {
            Gl.glPushMatrix();
            Gl.glTranslated(eulerRigidBody.Location.X,
                eulerRigidBody.Location.Y,
                eulerRigidBody.Location.Z);

            bool drawWireFrame = false;
            int drawStyle = drawWireFrame ? Glu.GLU_LINE :
                                                  Glu.GLU_FILL;

            Gl.glColor3f(this.colour.Red, this.colour.Green, this.colour.Blue);

            // From NeHe lesson 18.
            Glu.GLUquadric quadric = Glu.gluNewQuadric();
            try
            {
                Glu.gluQuadricDrawStyle(quadric, drawStyle);
                Glu.gluQuadricNormals(quadric, Glu.GLU_SMOOTH);
                Glu.gluSphere(quadric, radius, 40, 40);
            }
            finally
            {
                Glu.gluDeleteQuadric(quadric);
            }

            Gl.glPopMatrix();
        }

        #endregion IDrawable Implementation

        #region Member Variables

        private EulerRigidBody eulerRigidBody = null;
        private double radius = 1.0;
        private Colour colour;

        #endregion Member Variables
    }
}
