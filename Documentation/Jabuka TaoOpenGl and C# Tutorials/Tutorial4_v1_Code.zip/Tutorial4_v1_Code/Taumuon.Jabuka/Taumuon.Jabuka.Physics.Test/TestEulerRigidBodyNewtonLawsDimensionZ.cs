// Copyright Gary Evans 2006-2007.

using System;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Runs the dimension specific tests in the y dimension.
    /// </summary>
    [TestFixture]
    public class TestEulerRigidBodyNewtonLawsDimensionZ
        : TestEulerRigidBodyNewtonLawsDimensionSpecific
    {
        /// <summary>
        /// Default constructor. Sets the vectorAxis to the z
        /// dimension.
        /// </summary>
        public TestEulerRigidBodyNewtonLawsDimensionZ()
        {
            VectorAxis = 2;
        }
    }
}
