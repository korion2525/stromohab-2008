// Copyright Gary Evans 2006-2007.

using System;

using Tao.OpenGl;

namespace Taumuon.Jabuka.MainApp
{
    class Sphere : IDrawable, IDisposable
    {
        #region Object Lifetime

        public Sphere()
        {
            this.gluQuadricWrapper = new GluQuadricWrapper();
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        //~Sphere()
        //{
        //    this.Dispose(false);
        //}

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Dispose of any managed resources.
                gluQuadricWrapper.Dispose();
            }
        }

        #endregion Object Lifetime

        #region Member Variables

        private GluQuadricWrapper gluQuadricWrapper;
        private double sphereZLocation = 0.0;

        #endregion Member Variables

        #region Public Methods

        public void Draw()
        {
            Gl.glPushMatrix();
            Gl.glTranslated(0.0, 0.0, sphereZLocation);

            this.gluQuadricWrapper.DrawSphere();

            Gl.glPopMatrix();
        }

        /// <summary>
        /// The object updates its location by the given increment.
        /// </summary>
        public void Update(double increment)
        {
            this.sphereZLocation += increment;
        }

        #endregion Public Methods
    }
}
