// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

using Tao.OpenGl;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Manages the lifetime of a gluQuadric.
    /// </summary>
    public class GluQuadricWrapper
    {
        #region Object Lifetime

        /// <summary>
        /// Creates an instance of the GluQuadricWrapper
        /// </summary>
        public GluQuadricWrapper()
        {
            bool drawWireFrame = false;
            int drawStyle = drawWireFrame ? Glu.GLU_LINE :
                                                  Glu.GLU_FILL;
            this.gluQuadric = Glu.gluNewQuadric();
            Glu.gluQuadricDrawStyle(this.gluQuadric, drawStyle);
            Glu.gluQuadricCallback(this.gluQuadric, Glu.GLU_ERROR, new
                Glu.QuadricErrorCallback(this.QuadricErrorCallback));
            Glu.gluQuadricNormals(this.gluQuadric, Glu.GLU_SMOOTH);
        }

        /// <summary>
        /// Disposes of this instance.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// This instance's finalizer.
        /// </summary>
        ~GluQuadricWrapper()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Override this method to perform cleanup, and ensure
        ///  to call the base class method.
        /// </summary>
        /// <param name="disposing">Whether this instance is
        /// being disposed or finalized.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!isDisposed)
            {
                if (disposing)
                {
                    // Dispose of any managed resources.
                }

                Glu.gluQuadricCallback(this.gluQuadric, Glu.GLU_ERROR,
                    null);
                Glu.gluDeleteQuadric(this.gluQuadric);

                isDisposed = true;
            }
        }

        #endregion Object Lifetime

        #region Public Methods

        /// <summary>
        /// Draws a sphere.
        /// </summary>
        public void DrawSphere()
        {
            if (isDisposed)
            {
                throw new ObjectDisposedException("GluQuadricWrapper");
            }

            double radius = 5.0;

            // From NeHe lesson 18.
            Glu.gluSphere(this.gluQuadric, radius, 40, 40);
        }

        #endregion Public Methods

        #region Private Methods

        private void QuadricErrorCallback(int error)
        {
            throw new ApplicationException("An error has occurred: "
                + error.ToString());
        }

        #endregion Private Methods

        #region Member Variables

        private bool isDisposed = false;
        private Glu.GLUquadric gluQuadric;

        #endregion Member Variables
    }
}
