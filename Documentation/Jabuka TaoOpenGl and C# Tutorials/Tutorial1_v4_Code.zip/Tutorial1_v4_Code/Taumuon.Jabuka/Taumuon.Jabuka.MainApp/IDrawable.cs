// Copyright Gary Evans 2006-2007.

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Allows objects to be drawn.
    /// </summary>
    public interface IDrawable
    {
        /// <summary>
        /// Draws an object using OpenGL calls.
        /// </summary>
        void Draw();
        /// <summary>
        /// Lets the object update its position.
        /// </summary>
        /// <param name="increment">
        /// Time increment - larger numbers move object faster.
        /// </param>
        void Update(double increment);
    }
}
