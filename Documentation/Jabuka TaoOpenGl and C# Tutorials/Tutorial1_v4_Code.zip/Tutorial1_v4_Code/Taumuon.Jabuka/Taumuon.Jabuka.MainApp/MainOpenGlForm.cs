// Copyright Gary Evans 2006-2007.

using System;
using System.Windows.Forms;

using Tao.OpenGl;

namespace Taumuon.Jabuka.MainApp
{
    public partial class MainOpenGlForm : Form
    {
        #region Member Variables

        private World world = null;
        private readonly string originalTitle;
        private int frameCount = 0;
        private System.Diagnostics.Stopwatch stopwatch
            = new System.Diagnostics.Stopwatch();
        private const int updateRateMilliseconds = 5000;

        #endregion

        /// <summary>
        /// The Application's main form.
        /// </summary>
        public MainOpenGlForm(World world)
        {
            if (null == world)
            {
                throw new ArgumentNullException("world");
            }

            this.world = world;

            InitializeComponent();
            this.simpleOpenGlControl1.InitializeContexts();

            world.InitGl();
            world.SetView(this.Height, this.Width);

            this.originalTitle = this.Text;

            this.stopwatch.Start();
        }

        /// <summary>
        /// Handles the resizing of the form.
        /// </summary>
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            world.SetView(this.Height, this.Width);
        }

        private void simpleOpenGlControl1_Paint(object sender,
                                                PaintEventArgs e)
        {
            world.RenderScene();
            UpdateFrameRate();
        }

        private void UpdateFrameRate()
        {
            frameCount++;
            if (stopwatch.ElapsedMilliseconds >
                updateRateMilliseconds)
            {
                long elapsedMilliseconds = 
                    stopwatch.ElapsedMilliseconds;
                double framesPerSecond = frameCount * 1000.0
                    / elapsedMilliseconds;
                frameCount = 0;
                this.Text = string.Format("{0} ({1})",
                    this.originalTitle, framesPerSecond.ToString(
                    "F2", Application.CurrentCulture));
                stopwatch.Reset();
                stopwatch.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            world.UpdateLocations();
            this.Refresh();
        }
    }
}