// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Taumuon.Jabuka.MainApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Axes axes = new Axes();
            Sphere sphere = new Sphere();
            List<IDrawable> drawableObjects = new List<IDrawable>();
            drawableObjects.Add(axes);
            drawableObjects.Add(sphere);
            World world = new World(drawableObjects);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainOpenGlForm(world));
        }
    }
}