This code uses the 2.0.0 version of the Tao Framework (downloadable from www.taoframework.com).

When building this project, the references point to a Dependencies folder being present two folders below the solution folder:

SomeFolder
  \Dependencies
  \SomeOtherFolder
    \Taumuon.Jabuka
     Taumuon.Jabuka.sln

Make sure that the Dependencies folder contains the Tao dlls, or change the references in the project to point to where these are located.