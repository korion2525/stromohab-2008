// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

namespace Taumuon.Jabuka.Physics
{
    /// <summary>
    /// A unit quaternion represents a rotation in 3D space.
    /// </summary>
    public class Quaternion
    {
        #region Object Lifetime

        /// <summary>
        /// Default constructor. Construct a multiplication identity quaternion, Zero vector, scalar part = 1.
        /// Rotating a quaternion by the identity quaternion results in no change to the original quaternion.
        /// </summary>
        public Quaternion() : this(1.0, new Vector())
        {
        }

        /// <summary>
        /// Constructs a quaternion with the given scalar and vector values.
        /// </summary>
        /// <param name="scalar">The scalar value of the quaternion,
        /// should be bounded between -1 and 1.</param>
        /// <remarks>
        /// <param name="vector">The vector values of the quaternion.</param>
        /// Note that the vector passed in is stored in the quaternion and is the same instance as returned by
        ///  the Vector property.
        /// </remarks>
        public Quaternion(double scalar, Vector vector)
        {
            if (vector == null)
            {
                throw new ArgumentNullException("vector");
            }
            System.Diagnostics.Debug.Assert(Math.Abs(scalar) <= 1.0, "Scalar value is not within allowed range");
            this.scalar = scalar;
            this.vector = vector;
        }

        #region Static Factory Methods

        /// <summary>
        /// Creates a Quaternion from the given angle-axis representation.
        /// </summary>
        /// <param name="angle">The angle to rotate around the axis, in radians (anti-clockwise is positive).</param>
        /// <param name="axis">The axis of rotation.</param>
        /// <returns>A new quaternion instance representing the given rotation.</returns>
        /// <remarks>Note that the vector instance passed in is assigned to the created quaternion.</remarks>
        public static Quaternion MakeFromAngleAxis(double angle, Vector axis)
        {
            if (axis == null)
            {
                throw new ArgumentNullException("axis");
            }
            if (axis.Magnitude < Tolerance)
            {
                throw new ArgumentException("axis magnitude should be greater than zero");
            }
            return new Quaternion(Math.Cos(angle / 2.0), axis.Normalise() * Math.Sin(angle / 2.0));
        }

        #endregion Static Factory Methods

        #endregion Object Lifetime

        #region Properties

        /// <summary>
        /// The Scalar value of the quaternion.
        /// </summary>
        public double Scalar
        {
            get
            {
                return scalar;
            }
        }

        /// <summary>
        /// The Vector value of the quaternion.
        /// </summary>
        public Vector Vector
        {
            get
            {
                return vector;
            }
        }

        /// <summary>
        /// The angle of rotation, in radians, of the corresponding angle-axis representation of the quaternion.
        /// </summary>
        public double Angle
        {
            get
            {
                return 2 * Math.Acos(scalar);
            }
        }

        /// <summary>
        /// The axis of rotation, of the corresponding angle-axis representation of the quaternion.
        /// </summary>
        public Vector Axis
        {
            get
            {
                return vector.Normalise();
            }
        }

        /// <summary>
        /// The conjugate ~q of a quaternion q, has the same scalar, but its vector has its sign inversed.
        /// ~(qp) = (~p)(~q)
        /// </summary>
        /// <remarks>
        /// Returns a new instance, leaves the original unchanged.
        /// </remarks>
        public Quaternion Conjugate
        {
            get
            {
                return new Quaternion(this.scalar, this.vector * -1.0);
            }
        }

        #endregion Properties

        #region Public Methods

        // Derived here: http://www.euclideanspace.com/maths/algebra/realNormedAlgebra/quaternions/transforms/index.htm
        /// <summary>
        /// Rotates this quaterion by the rhs input.
        /// The resulting rotation quatertion p' is given by
        /// p' = (q)(p)
        /// p is this instance, q is the quaternion passed in.
        /// </summary>
        /// <param name="rhs">The quaternion representing a rotation to rotate this quaternion by.</param>
        /// <returns>The result of rotating this quaternion by the rhs input.</returns>
        /// <remarks>Returns a new quaternion instance, leaves the originals unchanged.</remarks>
        public Quaternion Rotate(Quaternion rhs)
        {
            // NOTE: normalise the result of the rotation to account for
            //  numerical errors (prevents the scalar value from becoming greater
            //  than (+/- 1.0).
            return (rhs * this).Normalise();
        }

        /// <summary>
        /// Returns a normalised copy of the quaternion.
        /// </summary>
        public Quaternion Normalise()
        {
            double magnitude = Math.Sqrt(
                  (scalar * scalar)
                + (vector.X * vector.X)
                + (vector.Y * vector.Y)
                + (vector.Z * vector.Z));

            return new Quaternion(scalar / magnitude, vector / magnitude);
        }

        /// <summary>
        /// Applies the rotation represented by this quaternion instance to the passed in vector.
        /// </summary>
        /// <param name="rhs">The vector to rotate this quaternion by.</param>
        /// <returns>The result of rotating the vector by this quaterion.</returns>
        /// <remarks>Returns a new vector instance, leaves the originals unchanged.</remarks>
        public Vector RotateVector(Vector rhs)
        {
            Quaternion temp = new Quaternion(0, rhs);
            return (this * temp * this.Conjugate).Vector;
        }

        #endregion Public Methods

        #region Operator Overloads

        /// <summary>
        /// Overloaded multiplication operator, for a quaterion 
        /// on both sides of the operation.
        /// </summary>
        /// <param name="lhs">The left-hand operand</param>
        /// <param name="rhs">The right-hand operand</param>
        /// <returns>
        /// Result of multiplication, leaving operands unchanged.
        /// </returns>
        public static Quaternion operator *(Quaternion lhs, Quaternion rhs)
        {
            return new Quaternion((lhs.scalar * rhs.scalar) - lhs.vector.DotProduct(rhs.vector),
                (rhs.vector * lhs.scalar) + (lhs.vector * rhs.scalar) + (lhs.vector.CrossProduct(rhs.vector)));
        }

        #endregion Operator Overloads

        #region Private Member Variables

        private double scalar;
        private Vector vector;

        #endregion Private Member Variables

        #region Statics

        private static double Tolerance = 1e-10;

        #endregion Statics
    }
}
