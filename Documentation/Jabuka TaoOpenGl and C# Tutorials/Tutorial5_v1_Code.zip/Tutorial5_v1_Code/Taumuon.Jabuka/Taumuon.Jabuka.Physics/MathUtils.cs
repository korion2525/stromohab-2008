// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

namespace Taumuon.Jabuka.Physics
{
    /// <summary>
    /// Utility methods for mathematics operations
    /// </summary>
    public static class MathUtils
    {
        /// <summary>
        /// Checks that the two values are equivalent, within
        ///  the absolute tolerance value.
        /// </summary>
        /// <returns>true if equal, false otherwise</returns>
        public static bool IsEqualWithinTol(double val1,
            double val2, double tolerance)
        {
            return Math.Abs(val1 - val2) < tolerance;
        }
    }
}
