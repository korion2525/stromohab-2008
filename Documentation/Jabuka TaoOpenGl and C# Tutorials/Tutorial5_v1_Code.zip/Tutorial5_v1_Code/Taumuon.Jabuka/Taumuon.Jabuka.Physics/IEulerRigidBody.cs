// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

namespace Taumuon.Jabuka.Physics
{
    /// <summary>
    /// Euler Rigid bodies should implement this interface.
    /// </summary>
    public interface IEulerRigidBody : ICloneable
    {
        #region Public Accessors

        /// <summary>
        /// Retrieves the current location.
        /// </summary>
        Vector Location { get; }

        /// <summary>
        /// Retrieves the current velocity.
        /// </summary>
        Vector Velocity { get; }

		/// <summary>
		/// Retrieves the current acceleration.
		///  This is the body's force (if any)
		///  divided by the body's mass.
		/// </summary>
		Vector Acceleration { get; }

		/// <summary>
		/// Retrieves the current force being applied to the object.
		/// </summary>
		Vector AppliedForce { get; }

        /// <summary>
        /// Returns the object's mass.
        /// </summary>
        double Mass { get; }

		/// <summary>
		/// Assigns the values of this EulerRigidBody and the values of its members
		///  from the values on the EulerRigidBody passed in.
		/// </summary>
		/// <param name="rhs">The EulerRigidBody to set the values from</param>
		/// <remarks>This sets all values, analogous to a deep copy.
		/// It does not change any of the original objects' or sub objects' references
		///  (only sets values on those references)</remarks>
		void AssignFromEulerRigidBody(IEulerRigidBody rhs);

        #endregion Public Accessors

        #region Public Methods

        /// <summary>
        /// Allows the body to update its physical state.
        /// </summary>
        /// <param name="deltaTime">Time increment, in seconds.</param>
        void Update(double deltaTime);

        /// <summary>
        /// Applies a force to the body.
        /// </summary>
        /// <param name="force">Force, in Newtons.</param>
        void ApplyForce(Vector force);

        #endregion Public Methods
    }
}
