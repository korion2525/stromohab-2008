// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Holds colour information
    /// </summary>
    public struct Colour
    {
        #region Object Lifetime

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="red">The red component, a value between 0.0 and 1.0</param>
        /// <param name="green">The green component, a value between 0.0 and 1.0</param>
        /// <param name="blue">The blue component, a value between 0.0 and 1.0</param>
        public Colour(float red, float green, float blue)
        {
            this.red = red;
            this.green = green;
            this.blue = blue;
        }

        #endregion Object Lifetime

        #region Properties

        /// <summary>
        /// The red component, a value between 0.0 and 1.0
        /// </summary>
        public float Red
        {
            get
            {
                return this.red;
            }
        }

        /// <summary>
        /// The green component, a value between 0.0 and 1.0
        /// </summary>
        public float Green
        {
            get
            {
                return this.green;
            }
        }

        /// <summary>
        /// The blue component, a value between 0.0 and 1.0
        /// </summary>
        public float Blue
        {
            get
            {
                return this.blue;
            }
        }

        #endregion Properties

        #region Member Variables

        private float red;
        private float green;
        private float blue;

        #endregion Member Variables
    }
}
