// Copyright Gary Evans 2006-2007.

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Allows objects to be drawn.
    /// </summary>
    public interface IDrawable
    {
        /// <summary>
        /// Draws an object using the OpenGL API.
        /// </summary>
        void Draw();
    }
}
