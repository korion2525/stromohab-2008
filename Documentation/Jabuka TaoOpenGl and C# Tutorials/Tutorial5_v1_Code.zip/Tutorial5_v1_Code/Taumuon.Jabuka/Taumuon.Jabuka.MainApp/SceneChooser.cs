// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Form to display a list of scenes to the user.
    /// </summary>
    public partial class SceneChooser : Form
    {
        /// <summary>
        /// constructor
        /// </summary>
        public SceneChooser(List<SceneDescription> sceneDescriptions)
        {
            InitializeComponent();

            foreach (SceneDescription description in sceneDescriptions)
            {
                this.listBoxScenes.Items.Add(description);
            }
            this.listBoxScenes.SelectedIndex = 0;
        }

        /// <summary>
        /// The currently selected SceneDescription
        /// </summary>
        public SceneDescription SelectedDescription
        {
            get
            {
                if (this.listBoxScenes.SelectedItem != null)
                {
                    return (SceneDescription)this.listBoxScenes.SelectedItem;
                }
                else
                {
                    return (SceneDescription)this.listBoxScenes.Items[0];
                }
            }
        }

        private void listBoxScenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.listBoxScenes.SelectedItem != null)
            {
                this.textBoxDescription.Text =
                    !string.IsNullOrEmpty(((SceneDescription)this.listBoxScenes.SelectedItem).Description)
                    ? ((SceneDescription)this.listBoxScenes.SelectedItem).Description : string.Empty;
            }
        }
    }
}