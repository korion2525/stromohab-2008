// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Interface that all Scene objects support.
    /// </summary>
    public interface IScene
    {
        /// <summary>
        /// The list of objects that will be drawn.
        /// </summary>
        List<IDrawable> DrawableObjects
        {
            get;
        }

        /// <summary>
        /// Resets the Scene to its starting point.
        /// </summary>
        void ResetScene();

        /// <summary>
        /// Updates all of the objects in the scene with the given time step.
        /// </summary>
        /// <param name="deltaTime">The time step, in seconds.</param>
        void Update(double deltaTime);

        /// <summary>
        /// This should return an array containing 4 entries - the parameters
        ///  to pass into Gl.glrotated (i.e. angle in degrees, then the 3
        ///  values specifying the rotation vector.
        /// If null is returned (or an array of any other size), then no rotation
        ///  occurs.
        /// </summary>
        /// <remarks>
        /// A nasty hack! This will be removed once we include a camera class.
        /// If this returns non-null, then the scene will be rotated.
        /// </remarks>
        double[] CameraRotation
        {
            get;
        }
    }
}
