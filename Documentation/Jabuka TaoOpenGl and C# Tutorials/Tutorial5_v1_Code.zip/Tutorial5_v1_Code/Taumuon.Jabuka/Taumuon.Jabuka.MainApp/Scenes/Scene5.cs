// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp.Scenes
{
    /// <summary>
    /// Rotating globe.
    /// </summary>
    [Scene("5. Rotating globe", "Demonstrates rotations via quaternions, does not use CollisionManager")]
    public class Scene5 : IScene
    {
        #region Object Lifetime

        /// <summary>
        /// Default Constructor
        /// </summary>
        public Scene5()
        {
            // Glu sphere draws a sphere with the poles aligned
            // along the z axis.
            // We want to display the sphere with the poles aligned
            // along the y axis, so we perform an initial 90 degree
            // rotation around the x axis.
            sphereOrientation = Quaternion.MakeFromAngleAxis(
                (15.0 / 16.0)
                * Math.PI / 2.0, new Vector(1.0, 0.0, 0.0));

            // We want to tilt the sphere by a rotation about the
            // world's z axis:
            sphereOrientation = sphereOrientation.Rotate(
                new Quaternion(
                Math.PI / 16.0, new Vector(0.0, 0.0, 1.0)));

            // The incremental rotation is about the body's local
            // z axis (aligned with the sphere's poles)
            increment = new Quaternion(0.1 / 100.0,
                new Vector(0.0, 0.0, 1.0));

            // Initialise the objects.
            ResetScene();
        }

        #endregion Object Lifetime

        #region IScene Implementation

        /// <summary>
        /// The list of objects that will be drawn.
        /// </summary>
        public List<IDrawable> DrawableObjects
        {
            get
            {
                return this.drawableObjects;
            }
        }

        /// <summary>
        /// Resets the Scene to its starting point.
        /// </summary>
        public void ResetScene()
        {
            Vector initialLocation = new Vector(0.0, -60.0, -120.0);
            Vector velocity = new Vector();
            const double mass = 1.0;
            eulerRigidBody = new EulerRigidBody(initialLocation, velocity, mass);
            Sphere sphere = new Sphere(eulerRigidBody, 80.0, new Colour(0.0f, 0.0f, 1.0f));

            // Set up the sphere's original rotation.
            eulerRigidBody.Orientation = sphereOrientation;

            rigidBodies = new List<EulerRigidBody>(1);
            rigidBodies.Add(eulerRigidBody);

            drawableObjects = new List<IDrawable>(1);
            drawableObjects.Add(sphere);
        }

        /// <summary>
        /// Updates all of the objects in the scene with the given
        /// time step.
        /// </summary>
        /// <param name="deltaTime">The time step, in seconds.</param>
        public void Update(double deltaTime)
        {
            foreach (EulerRigidBody rigidBody in this.rigidBodies)
            {
                rigidBody.Update(deltaTime);
                eulerRigidBody.Orientation = increment.Rotate(eulerRigidBody.Orientation);
            }
        }

        /// <summary>
        /// This should return an array containing 4 entries - the parameters
        ///  to pass into Gl.glrotated (i.e. angle in degrees, then the 3
        ///  values specifying the rotation vector.
        /// If null is returned (or an array of any other size), then no rotation
        ///  occurs.
        /// </summary>
        /// <remarks>
        /// A nasty hack! This will be removed once we include a camera class.
        /// If this returns non-null, then the scene will be rotated.
        /// </remarks>
        public double[] CameraRotation
        {
            get
            {
                return new double[] { 30.0, 1.0, 0.0, 0.0 };
            }
        }

        #endregion IScene Implementation

        #region Private Member Variables

        private EulerRigidBody eulerRigidBody = null;
        private List<EulerRigidBody> rigidBodies = null;
        private List<IDrawable> drawableObjects = null;
        private Quaternion sphereOrientation = null;
        private Quaternion increment = null;

        #endregion Private Member Variables
    }
}
