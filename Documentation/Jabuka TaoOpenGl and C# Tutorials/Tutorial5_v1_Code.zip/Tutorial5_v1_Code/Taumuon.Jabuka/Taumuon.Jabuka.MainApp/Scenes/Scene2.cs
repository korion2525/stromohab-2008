// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

using Taumuon.Jabuka.Physics;
using Collision = Taumuon.Jabuka.Physics.Collision;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Collisions with stationary objects.
    /// </summary>
    [Scene("2. 1D moving and stationary", "Collision between objects of differing mass, with one of the objects being stationary, along only one dimension.")]
    public class Scene2 : BaseScene
    {
        #region Overrides

        /// <summary>
        /// Resets the Scene to its starting point.
        /// </summary>
        public override void ResetScene()
        {
            List<Collision.Sphere> spheres = new List<Collision.Sphere>();
            drawableObjects = new List<IDrawable>();

            double locationY = -72.0;
            const double radius = 7.0;
            const double initialMovingVelocityX = 2.0;
            const double initialMovingLocationX = -25.0;
            const double initialStationaryLocationX = 15.0;
            AddSphere(Density.Low, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.Low, initialStationaryLocationX, locationY, 0.0, radius, spheres, drawableObjects);

            locationY = -52.0;
            AddSphere(Density.Low, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.Medium, initialStationaryLocationX, locationY, 0.0, radius, spheres, drawableObjects);

            locationY = -34.0;
            double radiusForDoubleVolume = radius * Math.Pow(2.0, 1.0 / 3.0);
            AddSphere(Density.Low, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.Low, initialStationaryLocationX + radiusForDoubleVolume - radius, locationY, 0.0, radiusForDoubleVolume, spheres, drawableObjects);

            locationY = -18.0;
            AddSphere(Density.Low, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.High, initialStationaryLocationX, locationY, 0.0, radius, spheres, drawableObjects);

            locationY = -2.0;
            AddSphere(Density.Medium, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.High, initialStationaryLocationX, locationY, 0.0, radius, spheres, drawableObjects);

            locationY = 14.0;
            AddSphere(Density.High, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.Medium, initialStationaryLocationX, locationY, 0.0, radius, spheres, drawableObjects);

            locationY = 30.0;
            AddSphere(Density.High, initialMovingLocationX, locationY, initialMovingVelocityX, radius, spheres, drawableObjects);
            AddSphere(Density.Low, initialStationaryLocationX, locationY, 0.0, radius, spheres, drawableObjects);

            this.collisionManager = new Collision.CollisionManager(spheres);
        }

        #endregion Overrides

        #region Helper Methods

        private void AddSphere(Density density, double initialLocationX, double initialLocationY,
            double initialVelocityX, double radius, List<Collision.Sphere> spheres, List<IDrawable> drawableObjects)
        {
            Vector initialLocation = new Vector(initialLocationX, initialLocationY, 0.0);
            Vector initialVelocity = new Vector(initialVelocityX, 0.0, 0.0);

            AddSphere(density, initialLocation, initialVelocity, radius, spheres, drawableObjects);
        }

        #endregion Helper Methods
    }
}
