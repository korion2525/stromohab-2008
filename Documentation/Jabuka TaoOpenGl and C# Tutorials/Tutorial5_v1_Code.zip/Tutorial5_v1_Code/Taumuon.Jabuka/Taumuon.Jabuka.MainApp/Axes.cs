// Copyright Gary Evans 2006-2007.

using System;

using Tao.OpenGl;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    class Axes : IDrawable
    {
        #region Object Lifetime

        /// <summary>
        /// Construct a drawable set of axes, aligned with the
        ///  world coordinate system.
        /// </summary>
        /// <param name="eulerRigidBody">
        /// The rigid body that is used to obtain the
        ///  axes's location.
        /// </param>
        /// <exception cref="ArgumentNullException"/>
        /// <remarks>
        /// Blue is aligned with the x axis,
        /// Green with the y axis and 
        /// Red with the z axis
        /// </remarks>
        public Axes(EulerRigidBody eulerRigidBody)
        {
            if (eulerRigidBody == null)
            {
                throw new ArgumentNullException("eulerRigidBody");
            }
            this.eulerRigidBody = eulerRigidBody;
        }

        #endregion Object Lifetime

        #region Member Variables

        private EulerRigidBody eulerRigidBody = null;

        #endregion Member Variables

        public void Draw()
        {
            Gl.glPushMatrix();
            Gl.glTranslated(eulerRigidBody.Location.X,
                eulerRigidBody.Location.Y, eulerRigidBody.Location.Z);

            const float axisSize = 25.0f;

            // draw a red line along the z-axis
            Gl.glColor3f(1.0f, 0.0f, 0.0f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3f(0.0f, 0.0f, -axisSize);
            Gl.glVertex3f(0.0f, 0.0f, axisSize);
            Gl.glEnd();

            // draw a green line along the y-axis
            Gl.glColor3f(0.0f, 1.0f, 0.0f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3f(0.0f, -axisSize, 0.0f);
            Gl.glVertex3f(0.0f, axisSize, 0.0f);
            Gl.glEnd();

            // draw a blue line along the x-axis
            Gl.glColor3f(0.0f, 0.0f, 1.0f);
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex3f(-axisSize, 0.0f, 0.0f);
            Gl.glVertex3f(axisSize, 0.0f, 0.0f);
            Gl.glEnd();

            Gl.glPopMatrix();
        }
    }
}
