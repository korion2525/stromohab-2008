// Copyright Gary Evans 2006-2007.

using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace Taumuon.Jabuka.Physics.Test
{
    /// <summary>
    /// Tests the quaternion operations.
    /// </summary>
    [TestFixture]
    public class TestQuaternion
    {
        #region Tests

        /// <summary>
        /// Tests that the Quaternion default constructor returns the identity quaternion.
        /// </summary>
        [Test]
        public void TestQuaternionDefaultConstructor()
        {
            Quaternion quaternion = new Quaternion();

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Scalar, 1.0, Tolerance),
                "Quaternion default constructor should produce quaternion with scalar value of 1.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Vector, 0.0, 0.0, 0.0),
                "Quaternion default constructor should produce quaternion with empty vector value");
        }

        /// <summary>
        /// Tests that the Quaternion constructor throws an exception when given a null vector.
        /// </summary>
        [ExpectedException(typeof(ArgumentNullException))]
        [Test]
        public void TestQuaternionConstructorNullVector()
        {
            Quaternion quaternion = new Quaternion(1.0, null);
        }

        /// <summary>
        /// Tests that the Quaternion constructor returns the values that it was constructed with.
        /// </summary>
        [Test]
        public void TestQuaternionConstructor()
        {
            Vector vector = new Vector(1.0, 0.0, 0.0);
            Quaternion quaternion = new Quaternion(1.0, vector);

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Scalar, 1.0, Tolerance),
                "Quaternion scalar value should be 1.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Vector, 1.0, 0.0, 0.0),
                "Quaternion vector should align with x axis");

            Assert.IsTrue(object.ReferenceEquals(vector, quaternion.Vector), "Original vector should be returned");
        }

        /// <summary>
        /// Tests that creating a quaterion using the AngleAxis factory method,
        ///  with a null axis vector throws the expected exception.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestQuaternionAngleAxisNullRotationVector()
        {
            Quaternion quaternion = Quaternion.MakeFromAngleAxis(0.0, null);
        }

        /// <summary>
        /// Tests that creating a quaterion using the AngleAxis factory method,
        ///  with an axis vector of zero magnitude throws the expected exception.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestQuaternionAngleAxisEmptyRotationVector()
        {
            Quaternion quaternion = Quaternion.MakeFromAngleAxis(0.0, new Vector());
        }

        /// <summary>
        /// Tests creating a quaternion using the AngleAxis factory method, with no rotation.
        /// </summary>
        [Test]
        public void TestQuaternionAngleAxisNoRotation()
        {
            Quaternion quaternion = Quaternion.MakeFromAngleAxis(0.0, new Vector(1.0, 0.0, 0.0));

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Scalar, 1.0, Tolerance),
                "Quaternion MakeFromAngleAxis from default vector should produce quaternion with scalar value of 1.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Vector, 0.0, 0.0, 0.0),
                "Quaternion MakeFromAngleAxis from default vector should produce quaternion with empty vector");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Angle, 0.0, Tolerance),
                "Quaternion MakeFromAngleAxis from default vector should produce quaternion with Angle of 0.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Axis, 0.0, 0.0, 0.0),
                "Quaternion MakeFromAngleAxis from default vector should produce quaternion with empty axis");
        }

        /// <summary>
        /// Tests creating a quaternion using the AngleAxis factory method, with a 180 degree
        ///  rotation about the x axis.
        /// </summary>
        [Test]
        public void TestQuaternionAngleAxis180DegRotationXAxis()
        {
            Quaternion quaternion = Quaternion.MakeFromAngleAxis(Math.PI, new Vector(1.0, 0.0, 0.0));

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Scalar, 0.0, Tolerance),
                "Quaternion MakeFromAngleAxis 180 deg around x axis should produce quaternion with scalar value of 1.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Vector, 1.0, 0.0, 0.0),
                "Quaternion MakeFromAngleAxis 180 deg around x axis should produce quaternion with Axis along x axis");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Angle, Math.PI, Tolerance),
                "Quaternion MakeFromAngleAxis 180 deg around x axis should produce quaternion with Angle of Math.Pi");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Axis, 1.0, 0.0, 0.0),
                "Quaternion MakeFromAngleAxis 180 deg around x axis should produce quaternion with Axis along x axis");
        }

        /// <summary>
        /// Tests the quaternion's Conjugate operator. The Conjugate leaves the scalar unchanged
        ///  but reverses the sign of the vector's values.
        /// </summary>
        [Test]
        public void TestQuaternionConjugate()
        {
            Quaternion quaternion = Quaternion.MakeFromAngleAxis(Math.PI, new Vector(1.0, 0.0, 0.0));

            Quaternion conjugate = quaternion.Conjugate;

            // assert original unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion.Scalar, 0.0, Tolerance),
                "Quaternion MakeFromAngleAxis 180 deg around x axis should produce quaternion with scalar value of 1.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion.Vector, 1.0, 0.0, 0.0),
                "Quaternion MakeFromAngleAxis 180 deg around x axis should produce quaternion with Axis along x axis");

            // check conjugate value
            Assert.IsTrue(MathUtils.IsEqualWithinTol(conjugate.Scalar, 0.0, Tolerance),
                "Quaternion MakeFromAngleAxis 180 deg around x axis's conjugate should produce quaternion with scalar value of 1.0");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(conjugate.Vector, -1.0, 0.0, 0.0),
                "Quaternion MakeFromAngleAxis 180 deg around x axis's conjugate should produce quaternion with axis reversed");
        }

        /// <summary>
        /// Tests the result of multiplying one quaternion by another.
        /// </summary>
        [Test]
        public void TestQuaternionMultiplicationPerpendicularAxes()
        {
            Quaternion quaternion1 = new Quaternion(0.5, new Vector(1.0, 0.0, 0.0));
            Quaternion quaternion2 = new Quaternion(0.7, new Vector(0.0, 1.0, 0.0));

            Quaternion result = quaternion1 * quaternion2;

            // assert originals unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion1.Scalar, 0.5, Tolerance),
                "quaternion1 scalar should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion1.Vector, 1.0, 0.0, 0.0),
                "quaternion1 vector should not be modified");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion2.Scalar, 0.7, Tolerance),
                "quaternion2 scalar should not be modified");   
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion2.Vector, 0.0, 1.0, 0.0),
                "quaternion2 vector should not be modified");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(result.Scalar, 0.35, Tolerance),
                "resulting scalar value is not correct");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(result.Vector, 0.7, 0.5, 1.0),
                "resulting vector is not correct");
        }

        /// <summary>
        /// Tests the result of multiplying one quaternion by another.
        /// </summary>
        [Test]
        public void TestQuaternionMultiplicationParallelAxes()
        {
            Quaternion quaternion1 = new Quaternion(0.5, new Vector(1.0, 0.0, 0.0));
            Quaternion quaternion2 = new Quaternion(0.7, new Vector(1.0, 0.0, 0.0));

            Quaternion result = quaternion2 * quaternion1;

            // assert originals unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion1.Scalar, 0.5, Tolerance),
                "quaternion1 scalar should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion1.Vector, 1.0, 0.0, 0.0),
                "quaternion1 vector should not be modified");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion2.Scalar, 0.7, Tolerance),
                "quaternion2 scalar should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion2.Vector, 1.0, 0.0, 0.0),
                "quaternion2 vector should not be modified");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(result.Scalar, -0.65, Tolerance),
                "resulting scalar value is not correct");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(result.Vector, 1.2, 0.0, 0.0),
                "resulting vector is not correct");
        }

        /// <summary>
        /// Tests the result of rotating one quaternion by another.
        /// </summary>
        [Test]
        public void TestQuaternionRotation()
        {
            Quaternion quaternion1 = Quaternion.MakeFromAngleAxis(0.5, new Vector(1.0, 0.0, 0.0));
            Quaternion quaternion2 = Quaternion.MakeFromAngleAxis(0.7, new Vector(1.0, 0.0, 0.0));

            Quaternion result = quaternion1.Rotate(quaternion2);

            // assert originals unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion1.Angle, 0.5, Tolerance),
                "quaternion1 angle should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion1.Axis, 1.0, 0.0, 0.0),
                "quaternion1 axis should not be modified");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(quaternion2.Angle, 0.7, Tolerance),
                "quaternion2 angle should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(quaternion2.Axis, 1.0, 0.0, 0.0),
                "quaternion2 axis should not be modified");

            Assert.IsTrue(MathUtils.IsEqualWithinTol(result.Angle, 1.2, Tolerance),
                "resulting angle value is not correct");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(result.Axis, 1.0, 0.0, 0.0),
                "resulting axis is not correct");
        }

        /// <summary>
        /// Tests the result of rotating a vector by the rotation represented by a quaterion
        ///  where the vector represents a point that lies on the axis of rotation leaves the 
        ///  point unchanged.
        /// </summary>
        [Test]
        public void TestVectorRotationAboutXAxis45DegNoRotation()
        {
            Quaternion q = Quaternion.MakeFromAngleAxis(Math.PI / 4.0, new Vector(1.0, 0.0, 0.0));

            Vector original = new Vector(1.0, 0.0, 0.0);
            Vector rotated = q.RotateVector(original);

            // assert original quaternion unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(q.Angle, Math.PI / 4.0, Tolerance),
                "quaternion1 angle should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(q.Axis, 1.0, 0.0, 0.0),
                "quaternion1 axis should not be modified");

            // assert original vector unchanged
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(original, 1.0, 0.0, 0.0),
                "original vector should not be modified");

            // assert rotated vector is correct
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotated, 1.0, 0.0, 0.0),
                "rotated vector is not correct");
        }

        /// <summary>
        /// Tests the result of rotating a vector by the rotation represented by a quaterion
        /// </summary>
        [Test]
        public void TestVectorRotationAboutXAxis45Deg()
        {
            Quaternion q = Quaternion.MakeFromAngleAxis(Math.PI / 4.0, new Vector(1.0, 0.0, 0.0));

            Vector original = new Vector(0.0, 1.0, 0.0);
            Vector rotated = q.RotateVector(original);

            // assert original quaternion unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(q.Angle, Math.PI / 4.0, Tolerance),
                "quaternion1 angle should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(q.Axis, 1.0, 0.0, 0.0),
                "quaternion1 axis should not be modified");

            // assert original vector unchanged
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(original, 0.0, 1.0, 0.0),
                "original vector should not be modified");

            // assert rotated vector is correct
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotated, 0.0, Math.Sqrt(2.0) / 2.0, Math.Sqrt(2.0) / 2.0),
                "rotated vector is not correct");
        }

        /// <summary>
        /// Tests the result of rotating a vector by the rotation represented by a quaterion
        /// </summary>
        [Test]
        public void TestVectorRotationAboutYAxis45Deg()
        {
            Quaternion q = Quaternion.MakeFromAngleAxis(Math.PI / 4.0, new Vector(0.0, 1.0, 0.0));

            Vector original = new Vector(1.0, 0.0, 0.0);
            Vector rotated = q.RotateVector(original);

            // assert original quaternion unchanged
            Assert.IsTrue(MathUtils.IsEqualWithinTol(q.Angle, Math.PI / 4.0, Tolerance),
                "quaternion1 angle should not be modified");
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(q.Axis, 0.0, 1.0, 0.0),
                "quaternion1 axis should not be modified");

            // assert original vector unchanged
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(original, 1.0, 0.0, 0.0),
                "original vector should not be modified");

            // assert rotated vector is correct
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotated, Math.Sqrt(2.0) / 2.0, 0.0, -Math.Sqrt(2.0) / 2.0),
                "rotated vector is not correct");
        }

        /// <summary>
        /// Tests the result of rotating a vector by the rotation represented by a quaterion
        /// </summary>
        [Test]
        public void TestVectorRotationAboutXEqualsYAxis180Deg()
        {
            Quaternion q = Quaternion.MakeFromAngleAxis(Math.PI, new Vector(1.0, 1.0, 0.0));

            Vector original = new Vector(0.0, 1.0, 0.0);
            Vector rotated = q.RotateVector(original);

            // assert rotated vector is correct
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotated, 1.0, 0.0, 0.0),
                "rotated vector is not correct");
        }

        /// <summary>
        /// Tests e.g a cylinder rotating about its axis, where its axis is tilted w.r.t the world's axis.
        /// </summary>
        [Test]
        public void TestQuaternionRotationRotateAboutTiltedLocalAxis()
        {
            Vector unrotated = new Vector(0.0, 1.0, 1.0);

            Quaternion quaternionRotationAboutLocalAxis = Quaternion.MakeFromAngleAxis(Math.PI / 2.0, new Vector(0.0, 1.0, 0.0));
            Quaternion quaternionRotationToTiltAxis = Quaternion.MakeFromAngleAxis(Math.PI / 4.0, new Vector(0.0, 0.0, 1.0));

            // First we simulate rotating a vector about a cylinder's local axis

            Vector rotatedAboutAxis = quaternionRotationAboutLocalAxis.RotateVector(unrotated);
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotatedAboutAxis, 1.0, 1.0, 0.0),
                "rotated vector about axis is not correct");

            // Then rotate the cylinder about the world's axis.

            Vector rotatedAboutTilted = quaternionRotationToTiltAxis.RotateVector(rotatedAboutAxis);
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotatedAboutTilted, 0.0, Math.Sqrt(2.0), 0.0),
                "rotated vector about tilted is not correct");

            // Check that this is equivalent to a vector rotation by a quaternion representing the combined rotation.

            // To simulate rotating a cylinder about its axis, want to rotate the local axis by the tilt axis
            //   i.e. pre-multiply the local rotation by the global rotation.
            Quaternion quaternionRotationCombined = quaternionRotationAboutLocalAxis.Rotate(quaternionRotationToTiltAxis);

            Vector rotatedAboutCombined = quaternionRotationCombined.RotateVector(unrotated);
            Assert.IsTrue(TestVector.AreVectorValuesCorrect(rotatedAboutCombined, 0.0, Math.Sqrt(2.0), 0.0),
                "rotated vector combined is not correct");
        }

        #endregion Tests

        private static double Tolerance = 1e-10;
    }
}
