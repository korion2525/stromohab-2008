// Copyright Gary Evans 2006.

using System;

using Tao.OpenGl;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    class Sphere : IDrawable
    {
        #region Object Lifetime

        /// <summary>
        /// Construct a drawable Sphere.
        /// </summary>
        /// <param name="eulerRigidBody">
        /// The rigid body that is used to obtain the
        ///  Sphere's location.
        /// </param>
        /// <exception cref="ArgumentNullException"/>
        public Sphere(EulerRigidBody eulerRigidBody)
        {
            if (eulerRigidBody == null)
            {
                throw new ArgumentNullException("eulerRigidBody");
            }
            this.eulerRigidBody = eulerRigidBody;
        }

        #endregion Object Lifetime

        #region Member Variables

        EulerRigidBody eulerRigidBody = null;

        #endregion Member Variables

        public void Draw()
        {
            Gl.glPushMatrix();
            Gl.glTranslated(eulerRigidBody.Location.X,
                eulerRigidBody.Location.Y,
                eulerRigidBody.Location.Z);

            bool drawWireFrame = false;
            int drawStyle = drawWireFrame ? Glu.GLU_LINE :
                                                  Glu.GLU_FILL;

            double radius = 5.0;

            // From NeHe lesson 18.
            Glu.GLUquadric quadric = Glu.gluNewQuadric();
            try
            {
                Glu.gluQuadricDrawStyle(quadric, drawStyle);
                Glu.gluQuadricNormals(quadric, Glu.GLU_SMOOTH);
                Glu.gluSphere(quadric, radius, 40, 40);
            }
            finally
            {
                Glu.gluDeleteQuadric(quadric);
            }

            Gl.glPopMatrix();
        }
    }
}
