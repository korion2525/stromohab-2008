// Copyright Gary Evans 2006.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Vector initialAxesLocation = new Vector(0.0, 0.0, 0.0);
            Vector axesVelocity = new Vector(0.0, 1.0, 0.0);
            const double axesMass = 1.0;
            EulerRigidBody axesRigidBody = new EulerRigidBody(
                initialAxesLocation, axesVelocity, axesMass);
            Axes axes = new Axes(axesRigidBody);

            Vector initialLocation = new Vector(20.0, 0.0, 0.0);
            Vector velocity = new Vector(2.0, 10.0, 0.0);
            const double mass = 1.0;
            EulerRigidBody eulerRigidBody =
                new EulerRigidBody(initialLocation, velocity, mass);
            Vector force = new Vector(0.0, -1.0, 0.0);
            eulerRigidBody.ApplyForce(force);
            Sphere sphere = new Sphere(eulerRigidBody);

            List<EulerRigidBody> rigidBodies =
                new List<EulerRigidBody>(2);
            rigidBodies.Add(eulerRigidBody);
            rigidBodies.Add(axesRigidBody);

            List<IDrawable> drawableObjects = new List<IDrawable>(2);
            drawableObjects.Add(axes);
            drawableObjects.Add(sphere);
            World world = new World(drawableObjects,rigidBodies);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(world));
        }
    }
}