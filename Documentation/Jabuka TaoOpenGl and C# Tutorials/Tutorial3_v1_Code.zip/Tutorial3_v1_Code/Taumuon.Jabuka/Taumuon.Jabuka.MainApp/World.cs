// Copyright Gary Evans 2006.

using System;
using System.Collections.Generic;
using System.Text;

using Tao.OpenGl;

using Taumuon.Jabuka.Physics;

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Holds a list of IDrawable objects, and draws them using
    ///     OpenGL calls.
    /// Usage:
    ///   Construct with a list of IDrawable objects,
    ///    and rigid bodies which will be integrated.
    ///   Call InitGl before making any calls.
    ///   Call SetView before doing any drawing, and when the
    ///       size of the viewport changes.
    ///   Call RenderScene to draw the objects to the screen.
    ///   Call UpdateLocations to update the object locations.
    /// </summary>
    public class World
    {
        #region Member Variables

        List<IDrawable> drawableObjects = null;
        List<EulerRigidBody> rigidBodies = null;

        #endregion Member Variables

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="drawableObjects">
        /// List of objects that support OpenGl drawing.
        /// </param>
        /// <param name="rigidBodies">
        /// List of rigid bodies that update their physical parameters.
        /// </param>
        /// <exception cref="ArgumentNullException"/>
        public World(List<IDrawable> drawableObjects,
            List<EulerRigidBody> rigidBodies)
        {
            if (null == drawableObjects)
            {
                throw new ArgumentNullException("drawableObjects");
            }
            if (null == rigidBodies)
            {
                throw new ArgumentNullException("rigidBodies");
            }
            this.drawableObjects = drawableObjects;
            this.rigidBodies = rigidBodies;
        }

        /// <summary>
        /// Draws a frame.
        /// </summary>
        internal void RenderScene()
        {
            // Clear Screen And Depth Buffer
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT |
                Gl.GL_DEPTH_BUFFER_BIT);
            Gl.glPushMatrix();

            // do our drawing here

            foreach (IDrawable drawableObject in drawableObjects)
            {
                drawableObject.Draw();
            }

            Gl.glPopMatrix();
            Gl.glFlush();
        }

        internal void SetView(int height, int width)
        {
            // Set viewport to window dimensions.
            Gl.glViewport(0, 0, width, height);

            // Reset projection matrix stack
            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();

            const float nRange = 80.0f;

            // Prevent a divide by zero
            if (height == 0)
            {
                height = 1;
            }

            // Establish clipping volume (left, right, bottom,
            // top, near, far)
            if (width <= height)
            {
                Gl.glOrtho(-nRange, nRange, -nRange * height / width,
                          nRange * height / width, -nRange, nRange);
            }
            else
            {
                Gl.glOrtho(-nRange * width / height,
                    nRange * width / height,
                    -nRange, nRange, -nRange, nRange);
            }

            // reset modelview matrix stack
            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();
        }

        internal void InitGl()
        {
            Gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            Gl.glShadeModel(Gl.GL_FLAT);
            Gl.glEnable(Gl.GL_DEPTH_TEST);
            Gl.glEnable(Gl.GL_CULL_FACE);
        }

        internal void UpdateLocations()
        {
            const double increment = 0.1;
            foreach (EulerRigidBody rigidBody in rigidBodies)
            {
                rigidBody.Update(increment);
            }
        }

        internal void ResetScene()
        {
            foreach (EulerRigidBody rigidBody in rigidBodies)
            {
                rigidBody.Location.X = 0.0;
                rigidBody.Location.Y = 0.0;
                rigidBody.Location.Z = 0.0;
                rigidBody.Velocity.X = 0.0;
                rigidBody.Velocity.Y = 0.0;
                rigidBody.Velocity.Z = 0.0;
            }
            // TODO: hack! World shouldn't have knowledge
            //  of objects initialisation!
            rigidBodies[0].Location.X = 20.0;
            rigidBodies[0].Velocity.X = 2.0;
            rigidBodies[0].Velocity.Y = 10.0;

            rigidBodies[1].Velocity.Y = 1.0;

        }
    }
}
