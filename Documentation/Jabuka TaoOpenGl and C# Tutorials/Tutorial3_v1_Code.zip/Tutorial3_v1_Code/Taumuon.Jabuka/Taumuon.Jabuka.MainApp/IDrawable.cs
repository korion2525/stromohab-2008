// Copyright Gary Evans 2006.

namespace Taumuon.Jabuka.MainApp
{
    /// <summary>
    /// Allows objects to be drawn.
    /// </summary>
    public interface IDrawable
    {
        /// <summary>
        /// Draws an object using OpenGL calls.
        /// </summary>
        void Draw();
    }
}
